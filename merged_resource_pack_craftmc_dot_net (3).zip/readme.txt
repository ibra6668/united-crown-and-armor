=====REMODELED MINECRAFT=====

INSTRUCTIONS:

REMOVING BUSHY LEAVES:
1. Go to \assets\minecraft\blockstates and search for 'leaves' in the explorer
2. Delete all the various leaves-files inside this folder

USING ALTERNATE TEXTURES:
There are a few alternate textures in this pack, you can use them by doing the following
1. Locate the alt textures, these are always located inside 'alt' folders
2. Example: '\assets\minecraft\textures\environment'
3. Open the folder and copy the alternate textures you want to use by overwriting the default ones

REMOVE EMISSIVE TEXTURES:
You can easily remove the emissive textures by deleting the 'emissive.properties' file
1. Delete '\assets\minecraft\optifine\emissive.properties'

COLORMAP ISSUES PRE 1.21.2 (BEFORE PALE GARDEN):
1. Go to '\assets\minecraft\optifine\colormap'
2. Change 'foliage.png' to the one named 'foliage_pre_1.21.2.png'
3. Do the same to '\assets\minecraft\optifine\colormap\grass.png'